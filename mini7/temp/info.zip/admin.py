from django.contrib import admin

# Register your models here.
from .models import Picture

admin.site.register(Picture)